#include <set>
#include <unordered_map>
// GNames And GUObjectArray Structure for UE4.18 ~ UE4.23 (PUBG)
// By @Kay at 01/11/2024

//#define WITH_CASE_PRESERVING_NAME



#define NAME_WIDE_MASK 0x1
#define NAME_INDEX_SHIFT 1
#define FORCEINLINE __attribute__((always_inline)) inline

namespace UE4
{
    typedef int8_t int8;
    typedef int16_t int16;
    typedef int32_t int32;
    typedef int64_t int64;
    typedef uint8_t uint8;
    typedef uint16_t uint16;
    typedef uint32_t uint32;
    typedef uint64_t uint64;
    
    enum {NAME_SIZE	= 1024};
    typedef int32_t NAME_INDEX;
    
    enum class ENameCase : uint8
    {
	    CaseSensitive,
	    IgnoreCase,
    };

    struct __attribute__((__packed__)) FNameEntry
    {
    private:
    	NAME_INDEX		Index;
	    FNameEntry*		HashNext;
        
    public:
    	union alignas(0)
	    {
	    	char   	AnsiName[NAME_SIZE];
	    	wchar_t	WideName[NAME_SIZE];
    	};
        
    public:
        
        FORCEINLINE int32 GetIndex() const
    	{
    		return Index >> NAME_INDEX_SHIFT;
    	}
        
        FORCEINLINE bool IsWide() const
    	{
	    	return (Index & NAME_WIDE_MASK);
    	}
        
        int32 GetNameLength() const
        {
            if (IsWide())
            {
                return wcslen(WideName);
            }
            else
            {
                return strlen(AnsiName);
            }
        }
        
        inline char const* GetAnsiName() const
        {
	    	if (IsWide())
                return "Wide";
	    	return AnsiName;
    	}
        
    	inline wchar_t const* GetWideName() const
    	{
	    	if (!IsWide())
                return L"Non-Wide";
	    	return WideName;
    	}
        
        FORCEINLINE std::string CPPString() const
        {
            if (!IsWide())
            {
                return std::string(AnsiName);
            }
            else
            {
                std::u16string u16str((char16_t*)WideName);
                return utf16_to_utf8(u16str);
            }
        }
    };
    static_assert(offsetof(FNameEntry, AnsiName) == 0xC);
    
    template<typename ElementType, int32 MaxTotalElements, int32 ElementsPerChunk>
    class TStaticIndirectArrayThreadSafeRead
    {
    	enum
    	{
    		// figure out how many elements we need in the master table
    		ChunkTableSize = (MaxTotalElements + ElementsPerChunk - 1) / ElementsPerChunk
    	};
    	ElementType** Chunks[ChunkTableSize];
    	int32 NumElements;
    	int32 NumChunks;
        
    public:
        FORCEINLINE int32 Num() const
    	{
	    	return NumElements;
    	}
        
        FORCEINLINE bool IsValidIndex(int32 Index) const
	    {
	    	return Index < Num() && Index >= 0;
    	}
        
        FORCEINLINE ElementType const* GetItemPtr(int32 Index) const
	    {
	    	int32 ChunkIndex = Index / ElementsPerChunk;
	    	int32 WithinChunkIndex = Index % ElementsPerChunk;
            
	    	if (!IsValidIndex(Index))
            {
                return nullptr;
            }
            
	    	if (ChunkIndex > NumChunks)
            {
                return nullptr;
            }
                
            if (Index > MaxTotalElements)
            {
                return nullptr;
            }
	    	
	    	ElementType** Chunk = Chunks[ChunkIndex];
	    	if (!Chunk) {
                return nullptr;
            }
            
	    	return *(ElementType**)(Chunk + WithinChunkIndex);
    	}
        
    };
    
    typedef TStaticIndirectArrayThreadSafeRead<FNameEntry, 2 * 1024 * 1024 /* 2M unique FNames */, 16384 /* allocated in 64K/128K chunks */ > TNameEntryArray;
    extern TNameEntryArray* GNames;
    
    class FName
    {
    public:
        FORCEINLINE NAME_INDEX GetComparisonIndexFast() const
        {
            return ComparisonIndex;
    	}
        
        FORCEINLINE NAME_INDEX GetDisplayIndexFast() const
        {
        #ifdef WITH_CASE_PRESERVING_NAME
	    	return DisplayIndex;
        #else
            return ComparisonIndex;
        #endif
	    }
        
        FORCEINLINE NAME_INDEX GetComparisonIndex() const
	    {
	    	const NAME_INDEX Index = GetComparisonIndexFast();
            if (Index < 0 || Index > GNames->Num()) return 0;
            //if (!(*GNames)[Index]) return 0;
	    	return Index;
	    }
        
        FORCEINLINE NAME_INDEX GetDisplayIndex() const
	    {
	    	const NAME_INDEX Index = GetDisplayIndexFast();
            if (Index < 0 || Index > GNames->Num()) return 0;
            //if (!(*GNames)[Index]) return 0;
	    	return Index;
	    }
        
        FORCEINLINE int32 GetNumber() const
        {
	    	return Number;
    	}
        
        const FNameEntry* GetComparisonNameEntry() const
        {
	        const NAME_INDEX Index = GetComparisonIndex();
            auto entry = GNames->GetItemPtr(Index);
            if (entry) {
                return entry;
            }
            return GNames->GetItemPtr(0);
        }
        
        const FNameEntry* GetDisplayNameEntry() const
        {
            const NAME_INDEX Index = GetDisplayIndex();
        	auto entry = GNames->GetItemPtr(Index);
            if (entry) {
                return entry;
            }
            return GNames->GetItemPtr(0);
        }
        
        FORCEINLINE char const* GetPlainANSIString() const
    	{
	    	return GetDisplayNameEntry()->GetAnsiName();
    	}
        
        FORCEINLINE wchar_t const* GetPlainWIDEString() const
    	{
	    	return GetDisplayNameEntry()->GetWideName();
    	}
        
        FORCEINLINE bool IsEqual(const FName& Other, const ENameCase CompareMethod = ENameCase::IgnoreCase, const bool bCompareNumber = true ) const
    	{
	    	return ((CompareMethod == ENameCase::IgnoreCase) ? GetComparisonIndexFast() == Other.GetComparisonIndexFast() : GetDisplayIndexFast() == Other.GetDisplayIndexFast())
		    	&& (!bCompareNumber || GetNumber() == Other.GetNumber());
    	}

    	FORCEINLINE bool operator==(const FName& Other) const
    	{
		#ifdef WITH_CASE_PRESERVING_NAME
			return GetComparisonIndexFast() == Other.GetComparisonIndexFast() && GetNumber() == Other.GetNumber();
		#else
			static_assert(sizeof(CompositeComparisonValue) == sizeof(*this), "ComparisonValue does not cover the entire FName state");
			return CompositeComparisonValue == Other.CompositeComparisonValue;
		#endif
    	}
        
	    FORCEINLINE bool operator!=(const FName& Other) const
    	{
	    	return !(*this == Other);
	    }
        
        FORCEINLINE bool IsNone() const
        {
	    	return GetComparisonIndexFast() == 0 && GetNumber() == 0;
    	}
        
        FORCEINLINE bool IsValid() const
	    {
	    	return GetComparisonIndexFast() >= 0 && GetComparisonIndexFast() < GNames->Num() && GNames->GetItemPtr(GetComparisonIndexFast()) != nullptr
		    	&& GetDisplayIndexFast() >= 0 && GetDisplayIndexFast() < GNames->Num() && GNames->GetItemPtr(GetDisplayIndexFast()) != nullptr;
    	}
        
        FORCEINLINE bool IsValidIndexFast() const
    	{
	    	return GetComparisonIndexFast() >= 0 && GetComparisonIndexFast() < GNames->Num()
		    	&& GetDisplayIndexFast() >= 0 && GetDisplayIndexFast() < GNames->Num();
    	}
        
        static FNameEntry const* GetEntry( int i )
    	{
            auto entry = GNames->GetItemPtr(i);
            if (entry) {
                return entry;
            }
            return GNames->GetItemPtr(0);
    	}
        
        std::string GetName()
{
    static std::unordered_map<NAME_INDEX, std::string> names_cached;
    if (names_cached.count(GetComparisonIndexFast()) > 0)
        return names_cached[GetComparisonIndexFast()];
    
    if (IsNone()) return "None";
    if (!IsValidIndexFast()) return "Invalid Name";
    
    auto entry = GetEntry(GetComparisonIndexFast());
    if (entry)
    {
        auto Name = entry->CPPString();
        std::size_t Pos = Name.rfind('/');
        if (Pos != std::string::npos) Name = Name.substr(Pos + 1);
        if (Name != "None") {
            if (Number > 0)
                Name += "_" + std::to_string(Number);
            names_cached[GetComparisonIndexFast()] = Name;
        }
        return Name;
    }
    return "Entry NULL";
}
    private:
        union {
            struct {
	        	NAME_INDEX		ComparisonIndex;
	        #ifdef WITH_CASE_PRESERVING_NAME
	        	NAME_INDEX		DisplayIndex;
        	#endif
	        	uint32			Number;
            };
        #ifndef WITH_CASE_PRESERVING_NAME
            uint64 CompositeComparisonValue;
        #endif
        };
    };
    static_assert(sizeof(FName) == 8);
    
    #pragma warning (push)
    #pragma warning (disable:4309)
    enum EObjectFlags : int32_t
    {
    	// Do not add new flags unless they truly belong here. There are alternatives.
    	// if you change any the bit of any of the RF_Load flags, then you will need legacy serialization
    	RF_NoFlags = 0x00000000,	///< No flags, used to avoid a cast

	    // This first group of flags mostly has to do with what kind of object it is. Other than transient, these are the persistent object flags.
    	// The garbage collector also tends to look at these.
    	RF_Public = 0x00000001,	///< Object is visible outside its package.
    	RF_Standalone = 0x00000002,	///< Keep object around for editing even if unreferenced.
    	RF_MarkAsNative = 0x00000004,	///< Object (UField) will be marked as native on construction (DO NOT USE THIS FLAG in HasAnyFlags() etc)
    	RF_Transactional = 0x00000008,	///< Object is transactional.
	    RF_ClassDefaultObject = 0x00000010,	///< This object is its class's default object
    	RF_ArchetypeObject = 0x00000020,	///< This object is a template for another object - treat like a class default object
    	RF_Transient = 0x00000040,	///< Don't save object.

    	// This group of flags is primarily concerned with garbage collection.
    	RF_MarkAsRootSet = 0x00000080,	///< Object will be marked as root set on construction and not be garbage collected, even if unreferenced (DO NOT USE THIS FLAG in HasAnyFlags() etc)
	    RF_TagGarbageTemp = 0x00000100,	///< This is a temp user flag for various utilities that need to use the garbage collector. The garbage collector itself does not interpret it.

	    // The group of flags tracks the stages of the lifetime of a uobject
    	RF_NeedInitialization = 0x00000200,	///< This object has not completed its initialization process. Cleared when ~FObjectInitializer completes
    	RF_NeedLoad = 0x00000400,	///< During load, indicates object needs loading.
	    RF_KeepForCooker = 0x00000800,	///< Keep this object during garbage collection because it's still being used by the cooker
    	RF_NeedPostLoad = 0x00001000,	///< Object needs to be postloaded.
	    RF_NeedPostLoadSubobjects = 0x00002000,	///< During load, indicates that the object still needs to instance subobjects and fixup serialized component references
    	RF_NewerVersionExists = 0x00004000,	///< Object has been consigned to oblivion due to its owner package being reloaded, and a newer version currently exists
    	RF_BeginDestroyed = 0x00008000,	///< BeginDestroy has been called on the object.
	    RF_FinishDestroyed = 0x00010000,	///< FinishDestroy has been called on the object.

    	// Misc. Flags
    	RF_BeingRegenerated = 0x00020000,	///< Flagged on UObjects that are used to create UClasses (e.g. Blueprints) while they are regenerating their UClass on load (See FLinkerLoad::CreateExport()), as well as UClass objects in the midst of being created
    	RF_DefaultSubObject = 0x00040000,	///< Flagged on subobjects that are defaults
    	RF_WasLoaded = 0x00080000,	///< Flagged on UObjects that were loaded
    	RF_TextExportTransient = 0x00100000,	///< Do not export object to text form (e.g. copy/paste). Generally used for sub-objects that can be regenerated from data in their parent object.
    	RF_LoadCompleted = 0x00200000,	///< Object has been completely serialized by linkerload at least once. DO NOT USE THIS FLAG, It should be replaced with RF_WasLoaded.
    	RF_InheritableComponentTemplate = 0x00400000, ///< Archetype of the object can be in its super class
    	RF_DuplicateTransient = 0x00800000,	///< Object should not be included in any type of duplication (copy/paste, binary duplication, etc.)
    	RF_StrongRefOnFrame = 0x01000000,	///< References to this object from persistent function frame are handled as strong ones.
    	RF_NonPIEDuplicateTransient = 0x02000000,	///< Object should not be included for duplication unless it's being duplicated for a PIE session
    	RF_Dynamic = 0x04000000,	///< Field Only. Dynamic field - doesn't get constructed during static initialization, can be constructed multiple times
    	RF_WillBeLoaded = 0x08000000,	///< This object was constructed during load and will be loaded shortly
    	RF_HasExternalPackage = 0x10000000,	///< This object has an external package assigned and should look it up when getting the outermost package
    };
    #pragma warning (pop)

    enum EFunctionFlags : uint32_t
    {
    	// Function flags.
    	FUNC_None = 0x00000000,
    	FUNC_Final = 0x00000001,				  // Function is final (prebindable, non-overridable function).
    	FUNC_RequiredAPI = 0x00000002,			  // Indicates this function is DLL exported/imported.
    	FUNC_BlueprintAuthorityOnly = 0x00000004, // Function will only run if the object has network authority
    	FUNC_BlueprintCosmetic = 0x00000008,	  // Function is cosmetic in nature and should not be invoked on dedicated servers
											  // FUNC_				= 0x00000010,   // unused.
											  // FUNC_				= 0x00000020,   // unused.
    	FUNC_Net = 0x00000040,					  // Function is network-replicated.
    	FUNC_NetReliable = 0x00000080,			  // Function should be sent reliably on the network.
    	FUNC_NetRequest = 0x00000100,			  // Function is sent to a net service
    	FUNC_Exec = 0x00000200,					  // Executable from command line.
    	FUNC_Native = 0x00000400,				  // Native function.
    	FUNC_Event = 0x00000800,				  // Event function.
    	FUNC_NetResponse = 0x00001000,			  // Function response from a net service
    	FUNC_Static = 0x00002000,				  // Static function.
    	FUNC_NetMulticast = 0x00004000,			  // Function is networked multicast Server -> All Clients
    	FUNC_UbergraphFunction = 0x00008000,	  // Function is used as the merge 'ubergraph' for a blueprint, only assigned when using the persistent 'ubergraph' frame
    	FUNC_MulticastDelegate = 0x00010000,	  // Function is a multi-cast delegate signature (also requires FUNC_Delegate to be set!)
    	FUNC_Public = 0x00020000,				  // Function is accessible in all classes (if overridden, parameters must remain unchanged).
    	FUNC_Private = 0x00040000,				  // Function is accessible only in the class it is defined in (cannot be overridden, but function name may be reused in subclasses.  IOW: if overridden, parameters don't need to match, and Super.Func() cannot be accessed since it's private.)
    	FUNC_Protected = 0x00080000,			  // Function is accessible only in the class it is defined in and subclasses (if overridden, parameters much remain unchanged).
    	FUNC_Delegate = 0x00100000,				  // Function is delegate signature (either single-cast or multi-cast, depending on whether FUNC_MulticastDelegate is set.)
    	FUNC_NetServer = 0x00200000,			  // Function is executed on servers (set by replication code if passes check)
    	FUNC_HasOutParms = 0x00400000,			  // function has out (pass by reference) parameters
    	FUNC_HasDefaults = 0x00800000,			  // function has structs that contain defaults
    	FUNC_NetClient = 0x01000000,			  // function is executed on clients
    	FUNC_DLLImport = 0x02000000,			  // function is imported from a DLL
    	FUNC_BlueprintCallable = 0x04000000,	  // function can be called from blueprint code
    	FUNC_BlueprintEvent = 0x08000000,		  // function can be overridden/implemented from a blueprint
    	FUNC_BlueprintPure = 0x10000000,		  // function can be called from blueprint code, and is also pure (produces no side effects). If you set this, you should set FUNC_BlueprintCallable as well.
    	FUNC_EditorOnly = 0x20000000,			  // function can only be called from an editor scrippt.
    	FUNC_Const = 0x40000000,				  // function can be called from blueprint code, and only reads state (never writes state)
    	FUNC_NetValidate = 0x80000000,			  // function must supply a _Validate implementation
    	FUNC_AllFlags = 0xFFFFFFFF,
    };

    class UClass;
    class UFunction;

    class __attribute__((__packed__)) UObject 
    {
    public:
        inline std::string GetName()
        {
            /*auto Name = GetUObjectName((uintptr_t)this);
            std::size_t Pos = Name.rfind('/');
            if (Pos != std::string::npos) Name = Name.substr(Pos + 1);
            return Name;*/
            return NamePrivate.GetName();
        }
    
    	std::string GetFullName();
    
        void ProcessEvent(UFunction *func, void *params)
        {
            return reinterpret_cast<void(*)(UObject*,UFunction*,void*)>(
               this->VTable[Offsets::ProcessEventIndex]
            )(this, func, params);
        }
    
        inline uintptr_t get() const { return reinterpret_cast<uintptr_t>(this); }
    
        bool IsA(UClass *cmp);
    
        static UClass *StaticClass();
    
        template <typename Base>
    	inline Base Cast() const { return Base(this); }
        
    private:
    	void**          VTable;
    public:
        EObjectFlags	ObjectFlags;
        int32_t		 InternalIndex;
    	UClass*         ClassPrivate;
        FName		   NamePrivate;
    	UObject*	    OuterPrivate;
    };
    static_assert(offsetof(UObject, ObjectFlags) == 0x8);
    static_assert(offsetof(UObject, InternalIndex) == 0xC);
    static_assert(offsetof(UObject, ClassPrivate) == 0x10);
    static_assert(offsetof(UObject, NamePrivate) == 0x18);
    static_assert(offsetof(UObject, OuterPrivate) == 0x20);
    static_assert(sizeof(UObject) == 0x28);

    class AActor : public UObject
    {
        char pad_0x28[0x438 - sizeof(UObject)];
        
    public:
        static UClass *StaticClass();
    };
    static_assert(sizeof(AActor) == 0x438);

    class UField : public UObject
    {
    public:
        UField *Next; // 0x28
    
        static UClass *StaticClass();
    };
    static_assert(sizeof(UField) == 0x30);

    class UStruct : public UField
    {
    public:
        UStruct *Super; // 0x30
        UField *Children; // 0x38
        char pad_0x40[0x40 - 0x38 - sizeof(Children)];
        int32_t PropertiesSize; // 0x40
        char pad_0x44[0x88 - 0x40 - sizeof(PropertiesSize)];
        
        static UClass *StaticClass();
    };
    static_assert(sizeof(UStruct) == 0x88);
    static_assert(offsetof(UStruct, Super) == 0x30);
    static_assert(offsetof(UStruct, Children) == 0x38);
    static_assert(offsetof(UStruct, PropertiesSize) == 0x40);

    class UClass : public UStruct
    {
    public:
        char pad_0x88[0x1a8];
    
        static UClass *StaticClass();
    };
    static_assert(sizeof(UClass) == 0x230);

    class UFunction : public UStruct {
    public:
        uint32_t FunctionFlags; // 0x88
        int16_t NumParams; // 0x8C
        int16_t ParamSize; // 0x8E
        char pad0[0xB0 - 0x8E - sizeof(ParamSize)];
        void *Func; // 0xB0
        char pad1[0xc0 - 0xB0 - sizeof(Func)];
    
        static UClass *StaticClass();
    };
    static_assert(sizeof(UFunction) == 0xc0);
    static_assert(offsetof(UFunction, FunctionFlags) == 0x88);
    static_assert(offsetof(UFunction, NumParams) == 0x8C);
    static_assert(offsetof(UFunction, ParamSize) == 0x8E);
    static_assert(offsetof(UFunction, Func) == 0xB0);

    std::string UObject::GetFullName()
    {
        std::string Name;
    	if (ClassPrivate)
    	{
        	std::string Temp;
        	for (UObject* CurrentOuter = OuterPrivate; IsValidPtr(CurrentOuter); CurrentOuter = CurrentOuter->OuterPrivate)
        	{
    	        Temp = CurrentOuter->GetName() + "." + Temp;
     	   }
    		Name = ClassPrivate->GetName();
    		Name += " ";
    		Name += Temp;
            Name += GetName();
        }
        return Name;
    }

    bool UObject::IsA(UClass *cmp)
    {
        for (auto super = ClassPrivate; super; super = super->Super->Cast<UClass*>())
        {
            if (super == cmp)
            {
                return true;
            }
        }
        return false;
    }

    enum EInternalObjectFlags : int32_t
    {
    	None = 0,
    	Native = 1 << 25,
    	Async = 1 << 26,
    	AsyncLoading = 1 << 27,
    	Unreachable = 1 << 28,
    	PendingKill = 1 << 29,
    	RootSet = 1 << 30,
    	NoStrongReference = 1 << 31
    };


    struct FUObjectItem
    {
    	// Pointer to the allocated object
    	class UObject* Object;

    	// Internal flags
    	int32_t Flags;

    	// UObject Owner Cluster Index
    	int32_t ClusterRootIndex;

    	// Weak Object Pointer Serial number associated with the object
    	int32_t SerialNumber;
    
        inline bool IsUnreachable() const
    	{
    		return !!(Flags & static_cast<std::underlying_type_t<EInternalObjectFlags>>(EInternalObjectFlags::Unreachable));
    	}
    	inline bool IsPendingKill() const
    	{
    		return !!(Flags & static_cast<std::underlying_type_t<EInternalObjectFlags>>(EInternalObjectFlags::PendingKill));
    	}
        
        FUObjectItem() : Object(nullptr), Flags(0), ClusterRootIndex(0), SerialNumber(0)
        {}
    };
    static_assert(sizeof(FUObjectItem) == 0x18);
    
    
    class FChunkedFixedUObjectArray
    {
    	enum
    	{
	    	NumElementsPerChunk = 64 * 1024,
    	};
        
    public:
    	FUObjectItem** Objects;
    	FUObjectItem* PreAllocatedObjects;
	    int32 MaxElements;
	    int32 NumElements;
    	int32 MaxChunks;
    	int32 NumChunks;
        
    public:
        FORCEINLINE int32 Num() const
        {
	    	return NumElements;
    	}

    	FORCEINLINE int32 Capacity() const
    	{
	    	return MaxElements;
    	}
        
        FORCEINLINE bool IsValidIndex(int32 Index) const
    	{
	    	return Index < Num() && Index >= 0;
    	}
        
        FORCEINLINE FUObjectItem const* GetObjectPtr(int32 Index) const
    	{
	    	const uint32 ChunkIndex = (uint32)Index / NumElementsPerChunk;
	    	const uint32 WithinChunkIndex = (uint32)Index % NumElementsPerChunk;
            if (!IsValidIndex(Index))
            {
                LOGE("!IsValidIndex %d", Index);
                return nullptr;
            }
            if (ChunkIndex > NumChunks)
            {
                LOGE("ChunkIndex > NumChunks: %d", ChunkIndex);
                return nullptr;
            }
            if (Index > MaxElements)
            {
                LOGE("Index > MaxElements: %d", Index);
                return nullptr;
            }
		    FUObjectItem* Chunk = Objects[ChunkIndex];
	    	if (!Chunk)
            {
                LOGE("Chunk NULL: %d", ChunkIndex);
                return nullptr;
            }
		    return Chunk + WithinChunkIndex;
	    }
        
    	FORCEINLINE FUObjectItem* GetObjectPtr(int32 Index)
    	{
		    const uint32 ChunkIndex = (uint32)Index / NumElementsPerChunk;
	    	const uint32 WithinChunkIndex = (uint32)Index % NumElementsPerChunk;
            if (!IsValidIndex(Index))
            {
                LOGE("!IsValidIndex %d", Index);
                return nullptr;
            }
            if (ChunkIndex > NumChunks)
            {
                LOGE("ChunkIndex > NumChunks: %d", ChunkIndex);
                return nullptr;
            }
            if (Index > MaxElements)
            {
                LOGE("Index > MaxElements: %d", Index);
                return nullptr;
            }
		    FUObjectItem* Chunk = Objects[ChunkIndex];
	    	if (!Chunk)
            {
                LOGE("Chunk NULL: %d", ChunkIndex);
                return nullptr;
            }
		    return Chunk + WithinChunkIndex;
	    }
        
        FORCEINLINE FUObjectItem const& operator[](int32 Index) const
	    {
	    	FUObjectItem const* ItemPtr = GetObjectPtr(Index);
	    	if (!ItemPtr) return *GetObjectPtr(0);
	        return *ItemPtr;
	    }
        
	    FORCEINLINE FUObjectItem& operator[](int32 Index)
    	{
	    	FUObjectItem* ItemPtr = GetObjectPtr(Index);
	    	if (!ItemPtr) return *GetObjectPtr(0);
	    	return *ItemPtr;
    	}
        
        int64 GetAllocatedSize() const
        {
            return MaxChunks * sizeof(FUObjectItem*) + NumChunks * NumElementsPerChunk * sizeof(FUObjectItem);
        }
        
        template<typename T> T FindUObject(const char* NameToFind) const
        {
        	for (int CurrentElement = 0; CurrentElement < NumElements; CurrentElement++)
        	{
        		const FUObjectItem* ObjectItem = GetObjectPtr(CurrentElement);
            
                if (!ObjectItem) continue;
            
                if (ObjectItem->IsPendingKill() || ObjectItem->IsUnreachable()) continue;
            
	    	    if (ObjectItem->Object->GetFullName() == NameToFind) {
		    	    LOGI("[SUCCESS] Object with the name \"%s\" was the %i object found.", NameToFind, CurrentElement);
            
		    	    return static_cast<T>(ObjectItem->Object);
	        	}
    	    }
            
    	    LOGI("[FAIL] All %i objects were checked for the name %s with no result.", NumElements, NameToFind);
	        return T{};
        }
        
        template<typename T> T FindUObject(const char* NameToFind)
        {
        	for (int CurrentElement = 0; CurrentElement < NumElements; CurrentElement++)
        	{
        		FUObjectItem* ObjectItem = GetObjectPtr(CurrentElement);
            
                if (!ObjectItem) continue;
            
                if (ObjectItem->IsPendingKill() || ObjectItem->IsUnreachable()) continue;
            
	    	    if (ObjectItem->Object->GetFullName() == NameToFind) {
		    	    LOGI("[SUCCESS] Object with the name \"%s\" was the %i object found.", NameToFind, CurrentElement);
            
		    	    return static_cast<T>(ObjectItem->Object);
	        	}
    	    }
            
    	    LOGI("[FAIL] All %i objects were checked for the name %s with no result.", NumElements, NameToFind);
	        return T{};
        }
        
        void Log()
        {
            std::ostringstream oss;
            oss << "Num: " << NumElements << std::endl;
            oss << "MaxNum: " << MaxElements << std::endl;
            oss << "NumChunks: " << NumChunks << std::endl;
            oss << "MaxChunks: " << MaxChunks << std::endl;
            oss << "Objects: 0x" <<std::hex<< (uintptr_t)Objects << std::endl;
            oss << std::dec;
            oss << "Name 0: " << FName::GetEntry(0)->CPPString() << std::endl;
            for (int CurrentElement = 0; CurrentElement < Num(); CurrentElement++)
    	    {
	        	FUObjectItem* ObjectItem = GetObjectPtr(CurrentElement);
                if (!ObjectItem) continue;
                
                LOGI("[%d] ObjectItem %lX", CurrentElement, ObjectItem);
                
                //if (ObjectItem->IsPendingKill() || ObjectItem->IsUnreachable()) continue;
            
	        	UObject* Object = ObjectItem->Object;
                if (!Object) continue;
                
                LOGI("[%d] Object %lX %s", CurrentElement, Object, Object->GetName().c_str());
            
                std::string fullname = Object->GetFullName();
                
                LOGI("[%d] FullName %s", CurrentElement, Object->GetFullName().c_str());
           
	    	    oss << "[" << CurrentElement << "] " << fullname << std::endl;
            
        	}
            std::ofstream outStream("/sdcard/Download/ObjectsDump.txt");
            outStream << oss.str();
            outStream.close();
        }
    };
    
    class FFixedUObjectArray
    {
        FUObjectItem* Objects;
	    int32 MaxElements;
    	int32 NumElements;
        
    public:
        FORCEINLINE FUObjectItem const* GetObjectPtr(int32 Index) const
    	{
	    	if (Index >= 0 && Index < NumElements)
	    	    return &Objects[Index];
            return nullptr;
    	}

    	FORCEINLINE FUObjectItem* GetObjectPtr(int32 Index)
    	{
	    	if (Index >= 0 && Index < NumElements)
	    	    return &Objects[Index];
            return nullptr;
    	}
        
        FORCEINLINE int32 Num() const
    	{
	    	return NumElements;
    	}
        
        FORCEINLINE int32 Capacity() const
    	{
	    	return MaxElements;
	    }

    	FORCEINLINE bool IsValidIndex(int32 Index) const
    	{
	    	return Index < Num() && Index >= 0;
    	}
        
        FORCEINLINE FUObjectItem const& operator[](int32 Index) const
    	{
	    	FUObjectItem const* ItemPtr = GetObjectPtr(Index);
	    	if (ItemPtr)
	        	return *ItemPtr;
            return {};
    	}

        
        template<typename T> T FindUObject(const char* NameToFind) const
        {
        	for (int CurrentElement = 0; CurrentElement < Num(); CurrentElement++)
        	{
        		const FUObjectItem* ObjectItem = GetObjectPtr(CurrentElement);
                if (!ObjectItem) continue;
                if (ObjectItem->IsPendingKill() || ObjectItem->IsUnreachable()) continue;
	    	    if (ObjectItem->Object->GetFullName() == NameToFind) {
		    	    return static_cast<T>(ObjectItem->Object);
	        	}
    	    }
	        return T{};
        }
        
        template<typename T> T FindUObject(const char* NameToFind)
        {
        	for (int CurrentElement = 0; CurrentElement < Num(); CurrentElement++)
        	{
        		const FUObjectItem* ObjectItem = GetObjectPtr(CurrentElement);
                if (!ObjectItem) continue;
                if (ObjectItem->IsPendingKill() || ObjectItem->IsUnreachable()) continue;
	    	    if (ObjectItem->Object->GetFullName() == NameToFind) {
		    	    return static_cast<T>(ObjectItem->Object);
	        	}
    	    }
	        return T{};
        }
        
        void Log()
        {
            std::ostringstream oss;
            oss << "Num: " << NumElements << std::endl;
            oss << "MaxNum: " << MaxElements << std::endl;
            oss << "Objects: 0x" <<std::hex<< (uintptr_t)Objects << std::endl;
            oss << std::dec;
            oss << "Name 0: " << FName::GetEntry(0)->CPPString() << std::endl;
            for (int CurrentElement = 0; CurrentElement < Num(); CurrentElement++)
    	    {
	        	FUObjectItem* ObjectItem = GetObjectPtr(CurrentElement);
                if (!ObjectItem) continue;
                
                LOGI("[%d] ObjectItem %lX", CurrentElement, ObjectItem);
                
                //if (ObjectItem->IsPendingKill() || ObjectItem->IsUnreachable()) continue;
            
	        	UObject* Object = ObjectItem->Object;
                if (!Object) continue;
                
                LOGI("[%d] Object %lX %s", CurrentElement, Object, Object->GetName().c_str());
            
                std::string fullname = Object->GetFullName();
                
                LOGI("[%d] FullName %s", CurrentElement, Object->GetFullName().c_str());
           
	    	    oss << "[" << CurrentElement << "] " << fullname << std::endl;
            
        	}
            std::ofstream outStream("/sdcard/Download/ObjectsDump.txt");
            outStream << oss.str();
            outStream.close();
        }
    };
    
    class FUObjectArray
    {
    	friend class UObject;
        
    public:
	    enum ESerialNumberConstants
	    {
	    	START_SERIAL_NUMBER = 1000,
	    };
        
        FORCEINLINE int32 ObjectToIndex(const class UObject* Object) const
	    {
	    	return Object->InternalIndex;
    	}
        
        FORCEINLINE FUObjectItem* IndexToObject(int32 Index)
    	{
		    if (!(Index >= 0)) return nullptr;
		    if (Index < ObjObjects.Num())
	    	{
			    return const_cast<FUObjectItem*>(ObjObjects.GetObjectPtr(Index));
	    	}
		    return nullptr;
	    }
        
        FORCEINLINE FUObjectItem* ObjectToObjectItem(const UObject* Object)
        {
	    	FUObjectItem* ObjectItem = IndexToObject(Object->InternalIndex);
	    	return ObjectItem;
    	}

    	FORCEINLINE int32 GetObjectArrayNum() const 
	    { 
		    return ObjObjects.Num();
	    }
        
        int32 GetObjectArrayCapacity() const
    	{
	    	return ObjObjects.Capacity();
	    }
        
    private:
	    //typedef TStaticIndirectArrayThreadSafeRead<UObjectBase, 8 * 1024 * 1024 /* Max 8M UObjects */, 16384 /* allocated in 64K/128K chunks */ > TUObjectArray;
    	//typedef FChunkedFixedUObjectArray TUObjectArray;
        typedef FFixedUObjectArray TUObjectArray; // PUBG use FFixedUObjectArray
        
        int32 ObjFirstGCIndex;
    	int32 ObjLastNonGCIndex;
        int32 MaxObjectsNotConsideredByGC;
        bool OpenForDisregardForGC;
    public:
        TUObjectArray ObjObjects;
        
    public:
    	TUObjectArray& GetObjectItemArrayUnsafe()
    	{
	    	return ObjObjects;
	    }
    
	    const TUObjectArray& GetObjectItemArrayUnsafe() const
	    {
	    	return ObjObjects;
    	}

        
        template<typename T> inline T Find(const char* NameToFind) const
        {
            return ObjObjects.FindUObject<T>(NameToFind);
        }
    };
    static_assert(offsetof(FUObjectArray, ObjObjects) == 0x10);
    
   
    TNameEntryArray* GNames = nullptr;
    FUObjectArray* GUObjectArray = nullptr;

    void Initialize(uintptr_t UE_BASE)
    {

        uintptr_t GNamesPtr = *(uintptr_t*)(UE_BASE + Offsets::GName);
        GNamesPtr = *(uintptr_t*)(GNamesPtr + 0x110);

        if (!GNamesPtr) {
            LOGE("GNames Error");
            return;
        }

        GNames = decltype(GNames)(GNamesPtr);
        GUObjectArray = decltype(GUObjectArray)(UE_BASE + Offsets::GUObjectArray);

        if (!GNames || !GUObjectArray) {
            LOGE("Initialization Error");
            return;
        }
    }
    UClass *UObject::StaticClass()
    {
        static UClass *obj;
        if (!obj)
            obj = GUObjectArray->Find<UE4::UClass*>("Class CoreUObject.Object");
        return obj;
    }
    
    UClass *AActor::StaticClass()
    {
        static UClass *obj;
        if (!obj)
            obj = GUObjectArray->Find<UE4::UClass*>("Class Engine.Actor");
        return obj;
    }

    UClass *UField::StaticClass()
    {
        static UClass *obj;
        if (!obj)
            obj = GUObjectArray->Find<UE4::UClass*>("Class CoreUObject.Field");
        return obj;
    }

    UClass *UStruct::StaticClass()
    {
        static UClass *obj;
        if (!obj) {
            obj = GUObjectArray->Find<UE4::UClass*>("Class CoreUObject.Struct");
            if (!obj)
                obj = GUObjectArray->Find<UE4::UClass*>("Class CoreUObject.struct");
        }
        return obj;
    }

    UClass *UClass::StaticClass()
    {
        static UClass *obj;
        if (!obj)
            obj = GUObjectArray->Find<UE4::UClass*>("Class CoreUObject.Class");
        return obj;
    }

    UClass *UFunction::StaticClass()
    {
        static UClass *obj;
        if (!obj)
            obj = GUObjectArray->Find<UE4::UClass*>("Class CoreUObject.Function");
        return obj;
    }
    
}

