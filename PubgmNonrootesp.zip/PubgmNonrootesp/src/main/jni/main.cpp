#include <list>
#include <vector>
#include <string>
#include <string.h>
#include <pthread.h>
#include <cstring>
#include <jni.h>
#include <unistd.h>
#include <fstream>
#include <iostream>
#include <GLES2/gl2.h>
#include <GLES2/gl2ext.h>
#include "Unity/Vector2.h"
#include "Unity/Vector3.h"
#include "Unity/Rect.h"
#include "Unity/Color.h"
#include "Unity/Quaternion.h"
#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "Includes/Chams.h"
#include "Includes/MonoString.h"
#include "Includes/Strings.h"
#include "menu.h"
#include "KittyMemory/KittyMemory.hpp"
#include "ESP/Drawing.h"
#include "ESP/hooks.h"
#include "ESP/Offsets.h"
#include "ESP/UE4Functions.h"
#include <Substrate/SubstrateHook.h>
#include <Substrate/CydiaSubstrate.h>
NepEsp es;
bool ESP, ESPLine, ESPBox;
float width = 1.0f;
Color color = Color::White();


KittyMemory::ProcMap UE4ProcMap;




template<class T>
class TArray
{
public:
    int Num() const
    {
        return m_nCount;
    }
    int Max() const
    {
        return m_nMax;
    }

    bool IsValid() const
    {
        if (m_nCount > m_nMax)
            return false;
        if (!IsValidPtr(m_Data))
            return false;
        return true;
    }

    uintptr_t GetAddress() const
    {
        return (uintptr_t)m_Data;
    }

    inline T GetByIndex(int i) const
    {
        if (i > m_nCount || i < 0) return {};
        return m_Data[i];
    }

protected:
    T* m_Data;
    uint32_t m_nCount;
    uint32_t m_nMax;
};

struct D3DMatrix {
    float _11, _12, _13, _14;
    float _21, _22, _23, _24;
    float _31, _32, _33, _34;
    float _41, _42, _43, _44;

    static D3DMatrix MatrixMultiply(const D3DMatrix& m1, const D3DMatrix& m2) {
        D3DMatrix pOut;
        pOut._11 = m1._11 * m2._11 + m1._12 * m2._21 + m1._13 * m2._31 + m1._14 * m2._41;
        pOut._12 = m1._11 * m2._12 + m1._12 * m2._22 + m1._13 * m2._32 + m1._14 * m2._42;
        pOut._13 = m1._11 * m2._13 + m1._12 * m2._23 + m1._13 * m2._33 + m1._14 * m2._43;
        pOut._14 = m1._11 * m2._14 + m1._12 * m2._24 + m1._13 * m2._34 + m1._14 * m2._44;
        pOut._21 = m1._21 * m2._11 + m1._22 * m2._21 + m1._23 * m2._31 + m1._24 * m2._41;
        pOut._22 = m1._21 * m2._12 + m1._22 * m2._22 + m1._23 * m2._32 + m1._24 * m2._42;
        pOut._23 = m1._21 * m2._13 + m1._22 * m2._23 + m1._23 * m2._33 + m1._24 * m2._43;
        pOut._24 = m1._21 * m2._14 + m1._22 * m2._24 + m1._23 * m2._34 + m1._24 * m2._44;
        pOut._31 = m1._31 * m2._11 + m1._32 * m2._21 + m1._33 * m2._31 + m1._34 * m2._41;
        pOut._32 = m1._31 * m2._12 + m1._32 * m2._22 + m1._33 * m2._32 + m1._34 * m2._42;
        pOut._33 = m1._31 * m2._13 + m1._32 * m2._23 + m1._33 * m2._33 + m1._34 * m2._43;
        pOut._34 = m1._31 * m2._14 + m1._32 * m2._24 + m1._33 * m2._34 + m1._34 * m2._44;
        pOut._41 = m1._41 * m2._11 + m1._42 * m2._21 + m1._43 * m2._31 + m1._44 * m2._41;
        pOut._42 = m1._41 * m2._12 + m1._42 * m2._22 + m1._43 * m2._32 + m1._44 * m2._42;
        pOut._43 = m1._41 * m2._13 + m1._42 * m2._23 + m1._43 * m2._33 + m1._44 * m2._43;
        pOut._44 = m1._41 * m2._14 + m1._42 * m2._24 + m1._43 * m2._34 + m1._44 * m2._44;
        return pOut;
    }

    D3DMatrix operator*(const D3DMatrix& rhs) const {
        return MatrixMultiply(*this, rhs);
    }
};



D3DMatrix g_matrix;
Vector2 g_screen;

D3DMatrix GetMatrix() {
    uintptr_t canvas_map = *(uintptr_t*)(UE4ProcMap.startAddress + Offsets::CanvasMap);
    if (!canvas_map) return {};

    uintptr_t canvas = *(uintptr_t*)(canvas_map + Offsets::canvas_map);
    if (!canvas) return {};

    return *(D3DMatrix*)(canvas + 0x9d0);
}

Vector3 W2S(const Vector3& worldLocation) {
    float screenW = (g_matrix._14 * worldLocation.x) + (g_matrix._24 * worldLocation.y) + (g_matrix._34 * worldLocation.z) + g_matrix._44;
    float screenX = (g_matrix._11 * worldLocation.x) + (g_matrix._21 * worldLocation.y) + (g_matrix._31 * worldLocation.z) + g_matrix._41;
    float screenY = (g_matrix._12 * worldLocation.x) + (g_matrix._22 * worldLocation.y) + (g_matrix._32 * worldLocation.z) + g_matrix._42;

    Vector3 result;


    if (screenW != 0) {
        result.y = (g_screen.Y / 2) - (g_screen.Y / 2) * screenY / screenW;
        result.x = (g_screen.X / 2) + (g_screen.X / 2) * screenX / screenW;
    }
    else {
        result.x = result.y = 0;
    }

    result.z = screenW;


    LOGI("World Location: (%f, %f, %f) -> Screen Position: (%f, %f)", worldLocation.x, worldLocation.y, worldLocation.z, result.x, result.y);

    return result;
}



template<typename T>
T Get(uintptr_t address) {
    T value;
    memcpy(&value, reinterpret_cast<void*>(address), sizeof(T));
    return value;
}

uintptr_t GetLocalUPlayer(uintptr_t gameInstance)
{
    bool bUseEncryptLocalPlayerPtr = Get<bool>(gameInstance + Offsets::bUseEncryptLocalPlayerPtr);
    if (bUseEncryptLocalPlayerPtr)
    {
        auto EncKey = *(uintptr_t*)(gameInstance + Offsets::LocalPlayer_Key);
        auto EncryptedLocalPlayers = Get<TArray<uintptr_t>>(gameInstance + Offsets::EncryptedLocalPlayers);
        if (EncryptedLocalPlayers.IsValid() && EncryptedLocalPlayers.Num() > 0)
        {
            auto enc = EncryptedLocalPlayers.GetByIndex(0);
            return enc ? (enc ^ EncKey) : 0;
        }
        return 0;
    }
    auto LocalPlayers = Get<TArray<uintptr_t>>(gameInstance + Offsets::LocalPlayers);
    if (LocalPlayers.IsValid() && LocalPlayers.Num() > 0)
        return LocalPlayers.GetByIndex(0);
    return 0;
}


void DrawESP(NepEsp esp, int screenWidth, int screenHeight) {
    g_screen.X = static_cast<float>(screenWidth);
    g_screen.Y = static_cast<float>(screenHeight);

    if (!ESP) return;

    auto GetUWorld = *(uintptr_t*)(UE4ProcMap.startAddress + Offsets::GEngine);
      if (!GetUWorld) return;
      
    auto getUworldNigga = *(uintptr_t*)(GetUWorld + Offsets::getUWorldNigga);
    if(!getUworldNigga) return;

    auto Uworld = *(uintptr_t*)(getUworldNigga + Offsets::UWorld);
    if (!Uworld) return;

    auto Ulevel = *(uintptr_t*)(Uworld + Offsets::Ulevel);
    if (!Ulevel) return;

    auto gameInstance = *(uintptr_t*)(Uworld + Offsets::gameInstance);
    if (!gameInstance) return;

    auto LocalUPlayer = GetLocalUPlayer(gameInstance);
    if (!LocalUPlayer) return;

    auto localActor = *(uintptr_t*)(LocalUPlayer + Offsets::localActor);
    if (!localActor) return;

    auto LocalPawn = *(uintptr_t*)(localActor + Offsets::LocalPawn);
    if (!LocalPawn) return;
    
    auto LocalRootComponent = *(uintptr_t*)(LocalPawn + Offsets::RootComponentt);
    if(!LocalRootComponent) return;

    TArray<uintptr_t>& ActorArray = *(TArray<uintptr_t>*)(Ulevel + 0xA0);

    for (int32_t i = 0; i < ActorArray.Num(); i++) {
        uintptr_t Actor = ActorArray.GetByIndex(i);
        if (!Actor) continue;

        void* RootComponent = *(void**)(Actor + 0x1b0);
        if (!RootComponent) continue;

        Vector3 Location = *(Vector3*)((uintptr_t)RootComponent + 0x184);
        g_matrix = GetMatrix();

       
        auto AActor = (UE4::AActor*)(Actor);
        auto name = AActor->GetName();
        if (LocalPawn == Actor) continue;

        int MyTeam = *(int*)(LocalPawn + 0x938);
        int teamid = *(int*)(Actor + 0x938);
        if (MyTeam == teamid) continue;

        if (name.find("BP_Character") == std::string::npos && name.find("BP_PlayerCharacter") == std::string::npos) {
            continue;
        }

        if (LocalPawn == Actor) continue;


        Vector3 PlayerFootPos = Location;
        Vector3 PlayerHeadPos = Location;
        PlayerHeadPos.z += (1.7f * 100.f) / 2;
        PlayerFootPos.z -= (1.7f * 100.f) / 2;

        Vector3 FootPosScreen = W2S(PlayerFootPos);
        Vector3 HeadPosScreen = W2S(PlayerHeadPos);

        if (HeadPosScreen.z < 0 || FootPosScreen.z < 0) {

            continue;
        }

        float height = std::abs(FootPosScreen.y - HeadPosScreen.y);
        float width = height * 0.4f;
        if (ESPLine) {
            Color lineColor(0, 255, 0, 255);
            Vector2 bottomScreenCenter(screenWidth / 2, screenHeight);
            Vector2 playerScreenPos(FootPosScreen.x, FootPosScreen.y);
            esp.DrawLine(lineColor, 2.f, bottomScreenCenter, playerScreenPos);
            
    }
}

}

extern "C"
JNIEXPORT void JNICALL
Java_uk_lgl_modmenu_FloatingModMenuService_DrawOn(JNIEnv *env, jclass type, jobject espView, jobject canvas) {
                es = NepEsp(env, espView, canvas);
    if (es.isValid()){
        DrawESP(es, es.getWidth(), es.getHeight());
    }
    
 }





void* hack_thread(void*) {
    printf("bitch");
    do {
        sleep(1);
        UE4ProcMap = KittyMemory::getElfBaseMap("libUE4.so");
    } while (!UE4ProcMap.isValid());
    sleep(15);
    printf("Done");
UE4::Initalize(UE4ProcMap.startAddress); 

return NULL;
 
}

extern "C" {
    JNIEXPORT jobjectArray
    JNICALL
    Java_uk_lgl_modmenu_FloatingModMenuService_getFeatureList(JNIEnv *env, jobject context) {
        jobjectArray ret;
        const char *features[] = {
            
            "100_Toggle_ Enable Esp ",
            "200_Toggle_ Esp Line ",

            
			
        };
        int Total_Feature = (sizeof features / sizeof features[0]);
        ret = (jobjectArray)
        env->NewObjectArray(Total_Feature, env->FindClass(OBFUSCATE("java/lang/String")),
        env->NewStringUTF(""));

        for (int i = 0; i < Total_Feature; i++)
        env->SetObjectArrayElement(ret, i, env->NewStringUTF(features[i]));

        return (ret);
    }


    JNIEXPORT void JNICALL
    Java_uk_lgl_modmenu_Preferences_Changes(JNIEnv *env, jclass clazz, jobject obj,
        jint featNum, jstring featName, jint value,
        jboolean boolean, jstring str) {

        switch (featNum) {
			
        case 100:
        ESP = boolean;
        break;
			
        case 200:
        ESPLine = boolean;
        break;
      
        
        }
    }
}

__attribute__((constructor))
void lib_main() {

    pthread_t ptid;
    pthread_create(&ptid, NULL, hack_thread, NULL);
}


// Check platinmods.com site for more info about esp making.

